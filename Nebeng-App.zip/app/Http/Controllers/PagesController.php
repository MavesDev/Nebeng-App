<?php

namespace App\Http\Controllers;

use App\Models\Riwayat;
use App\Models\UserData;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function beranda(){
        $userCount = DB::table('user_data')->count();
        return view('Dashboard',compact('userCount'));
    }
    public function login(){
        return view('Login');
    }

    public function settings(){
        return view('Setting');
    }

    public function kelolaData(){
        $data = UserData::all();
        return view('content.Data',compact('data'));
    }

    public function detail($id)
    {
        $data = UserData::find($id);
        return view('content.Detail', compact('data'));
    }

    public function rekap()
    {
        $data = Riwayat::all();
        return view('content.Rekap', compact('data'));
    }

    public function feedback()
    {
        $data = UserData::all();
        return view('content.Feedback', compact('data'));
    }

    public function history()
    {
        $data = Riwayat::all();
        $dataonce = null;
        return view('content.History', compact('data','dataonce'));
    }

    public function detailhistory($id){
        $data = Riwayat::all();
        $dataonce = Riwayat::find($id);
        return view('content.History', compact('data','dataonce'));
    }
}
