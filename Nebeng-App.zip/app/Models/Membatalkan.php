<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Membatalkan extends Model
{
    protected $table = 'membatalkan';
    use HasFactory;
}
