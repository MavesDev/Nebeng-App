<?php $__env->startSection('title', 'Kelola Data User'); ?>

<?php $__env->startSection('content'); ?>

<div class="data-user">
    <div class="data-user-title">
        <h2> Kelola Data User</h2>
    </div>

    <!-- Ini bagian buat button search dan filter -->
    <div class="data-user-filter">
        <div class="data-user-button">
            <button onclick="modalToogle()"> Filter <i class="fas fa-filter"></i> </button>
        </div>

        <div class="data-user-search">
            <form action="">
                <input type="text" placeholder="Search here....">
                <button type="submit">Search <i class="fas fa-search"></i></button>
            </form>
        </div>
    </div>

    <!-- ini buat tabelnya -->
    <div class="data-user-table">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIS</th>
                    <th>No Telepon</th>
                    <th>email</th>
                    <th>Edit</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <th>1</th>
                    <td><?php echo e($dt->nama_lengkap); ?></td>
                    <td><?php echo e($dt->nis); ?></td>
                    <td><?php echo e($dt->no_telp); ?></td>
                    <td><?php echo e($dt->email); ?></td>
                    <td>
                        <a class="fas fa-edit" href="#" onclick="showToogle()"></a>
                        <a class="fas fa-trash" href="#"></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Modals untuk filter -->
    <div class="modal-form">
        <div class="form">
            <div class="text">
                <h1> Filter </h1>
            </div>
            <form action="" method="post">
                <div class="txt-form">
                    <label for=""> Jenis Kelamin </label>
                    <select>
                        <option value="2022" selected>2022</option>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                    </select>
                </div>
                <div class="txt-form">
                    <label for=""> Kendaraan </label>
                    <select>
                        <option value="2022" selected>2022</option>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                    </select>
                </div>
                <div class="txt-form">
                    <label for=""> Rating </label>
                    <select>
                        <option value="2022" selected>2022</option>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                    </select>
                </div>
                <div class="button-form">
                    <button id="button-submit" type="submit"> Lets Filter! </button>
                    <a id="button-submit" onclick="modalToogle()"> Back </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal buat edit, maapkan males ganti class lagi :D -->
    <div class="show-form">
        <div class="form">
            <div class="text">
                <h1> Edit User </h1>
                <form action="" method="post">
                    <div class="txt-form">
                        <label for=""> User Profile </label>
                        <input type="text" placeholder="Please fill this form...">
                    </div>
                    <div class="txt-form">
                        <label for=""> User Profile </label>
                        <input type="text" placeholder="Please fill this form...">
                    </div>
                    <div class="button-form">
                        <button id="button-submit" type="submit"> Edit </button>
                        <a id="button-submit" onclick="showToogle()"> Kembali </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    // Fungsi Keluarin Modals Filter
    function modalToogle() {
        var container = document.querySelector('.modal-form');
        container.classList.toggle('active')
    }

    // Fungsi Keluarin Modals Show
    function showToogle() {
        var container = document.querySelector('.show-form');
        container.classList.toggle('active')
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Alghifari\Documents\Project PKK\Nebeng-App\resources\views/content/DataUser.blade.php ENDPATH**/ ?>