

<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<div class="show">
    <h2>Detail</h2>

    <div class="show-bg">
        <div class="show-title">
            <div class="show-photo">
                <img src="<?php echo e(asset('/image/face/s.png')); ?>" alt="">
            </div>
            <div class="show-name">
                <h4><?php echo e($data->nama_lengkap); ?></h4>
                <p><?php echo e($data->no_telp); ?></p>
            </div>
            <div class="show-link">
                <a href="#" onclick="showToogle()"><i class="fas fa-edit"></i></a>
                <form action="/keloladata/hapus/<?php echo e($data->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button><i class="fas fa-trash"></i></button>
                </form>
            </div>
        </div>
        <div class="show-content">
            <div class="show-desc">
                <label for="">Email</label>
                <p><?php echo e($data->email); ?></p>
            </div>
            <div class="show-desc">
                <label for="">No. Telp</label>
                <p><?php echo e($data->no_telp); ?></p>
            </div>
            <div class="show-desc">
                <label for="">Jenis Kelamin</label>
                <p><?php echo e($data->jenis_kelamin); ?></p>
            </div>
            <div class="show-desc">
                <label for="">Tanggal Daftar</label>
                <p><?php echo e($data->created_at); ?></p>
            </div>
            <div class="show-desc">
                <label for="">Kendaraan</label>
                <?php if($data->kendaraan != null): ?>
                <p><?php echo e($data->Kendaraan->merk_kendaraan); ?></p>
                <?php else: ?>
                <p>-</p>
                <?php endif; ?>
            </div>
            <div class="show-desc">
                <label for="">Rating</label>
                <p><?php echo e($data->rating); ?></p>
            </div>
        </div>
    </div>

    <div class="show-form">
        <div class="form">
            <div class="text">
                <h1> Detail User </h1>
                <form action="/keloladata/edit/<?php echo e($data->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="txt-form">
                        <label for=""> Nis </label>
                        <input type="text" placeholder="Nis..." value="<?php echo e($data->nis); ?>" name="nis">
                    </div>
                    <div class="txt-form">
                        <label for=""> Nama Lengkap </label>
                        <input type="text" placeholder="Nama..." value="<?php echo e($data->nama_lengkap); ?>" name="nama_lengkap">
                    </div>
                    <div class="txt-form">
                        <label for=""> Email </label>
                        <input type="text" placeholder="Email..." value="<?php echo e($data->email); ?>" name="email">
                    </div>
                    <div class="txt-form">
                        <label for=""> No Telepon </label>
                        <input type="text" placeholder="NoTelepon..." value="<?php echo e($data->no_telp); ?>" name="no_telp">
                    </div>
                    <div class="txt-form">
                        <label for=""> Jenis Kelamin </label>
                        <select name="jenis_kelamin" id="">
                            <option value="laki-laki" <?php echo e($data->jenis_kelamin == 'laki-laki' ? 'selected':''); ?>>Laki-Laki</option>
                            <option value="perempuan" <?php echo e($data->jenis_kelamin == 'perempuan' ? 'selected':''); ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="txt-form">
                        <label for=""> Password </label>
                        <input type="password" placeholder="Password..." value="<?php echo e($data->password); ?>" name="password">
                    </div>
                    <div class="button-form">
                        <button id="button-submit" type="submit"> Edit </button>
                        <a id="button-submit" onclick="showToogle()"> Kembali </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
    // Fungsi Keluarin Modals Show
    function showToogle() {
        var container = document.querySelector('.show-form');
        container.classList.toggle('active')
    }

      // Fungsi Keluarin Modals
      function loginToogle() {
            var container = document.querySelector('.login-form');
            container.classList.toggle('active')
        }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Alghifari\Documents\Project PKK\Nebeng-App\resources\views/content/Detail.blade.php ENDPATH**/ ?>