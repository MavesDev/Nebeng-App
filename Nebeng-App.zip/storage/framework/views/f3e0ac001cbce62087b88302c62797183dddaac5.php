

<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('container'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

<body>
    <section class="setting">
        <h4>Pengaturan Akun</h4>
        <div class="setting-image">
            <img src="<?php echo e(url('image/None.png')); ?>" alt="">
        </div>
        <div class="setting-form">
            <form action="/settings" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h3>Informasi Pribadi</h3>
                <div class="txt-form">
                    <input type="text" placeholder="Masukan Nama..." value="<?php echo e(Auth::user()->nama_admin); ?>" name="nama_admin" autocomplete="off">
                </div>
                <div class="txt-form">
                    <input type="text" placeholder="Masukan Username..." value="<?php echo e(Auth::user()->username_admin); ?>" name="username_admin" autocomplete="off">
                </div>
                <h3>Ganti Gambar</h3>
                <div class="txt-form">
                    <input type="file" name="image" id="">
                </div>
                <h3>Ganti Password</h3>
                <div class="txt-form">
                    <input type="password" placeholder="Masukan Password Sebelumnnya...." name="password_admin">
                </div>
                <div class="txt-form">
                    <input type="password" placeholder="Masukan Password Baru.." name="new_password">
                </div>
                <div class="button-form">
                    
                    <form action="#" method="POST">
                        <button type="submit"> Konfirmasi </button>
                    </form>
                    <a href="/"> Kembali </a>
                </div>
            </form>
        </div>
    </section>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Alghifari\Documents\Project PKK\Nebeng-App\resources\views/Setting.blade.php ENDPATH**/ ?>